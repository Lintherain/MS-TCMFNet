"""Frozen MS-TCMFNet measurement replay.  Usage: python inference.py [development|validation]."""
import csv, hashlib, math, sys
from pathlib import Path
import numpy as np
import torch
from mstcmfnet import MSTCMFNet

ROOT = Path(__file__).resolve().parent
MODELS = [{'seed': 20261018, 'file': 'Models/H0_seed20261018.pt', 'sha256': '78eaab235d6db9e88a524de24654365d2b1a7af0e5c566defec234939bde40c7'}, {'seed': 20261019, 'file': 'Models/H0_seed20261019.pt', 'sha256': '0d782a12cf3311a2f1c1380c69ca8ccbe1e61dd9055bef70bb7f16515c12cde9'}, {'seed': 20261020, 'file': 'Models/H0_seed20261020.pt', 'sha256': '9bf2414b75df29e1d966bfd4d7712a9d3c1c16cd4d2d95ec72de90f9a0c1a34a'}, {'seed': 20261021, 'file': 'Models/H0_seed20261021.pt', 'sha256': '65038c05e892a54864758bd57d6141fa7338af0fe6190bbadb64b8834ad8a8b2'}, {'seed': 20261022, 'file': 'Models/H0_seed20261022.pt', 'sha256': '911c05733d33558d4e2622a8a63f282a7d7e5a9d16e5f9bd8adadd81feb255fa'}]
RECORDS = [{'split': 'development', 'id': 'C010R1', 'file': 'Data/development/C010R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 10.0}, {'split': 'development', 'id': 'C020R1', 'file': 'Data/development/C020R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 20.0}, {'split': 'development', 'id': 'C030R1', 'file': 'Data/development/C030R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 30.0}, {'split': 'development', 'id': 'C040R1', 'file': 'Data/development/C040R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 40.0}, {'split': 'development', 'id': 'C060R1', 'file': 'Data/development/C060R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 60.0}, {'split': 'development', 'id': 'C070R1', 'file': 'Data/development/C070R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 70.0}, {'split': 'development', 'id': 'C080R1', 'file': 'Data/development/C080R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 80.0}, {'split': 'development', 'id': 'C090R1', 'file': 'Data/development/C090R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 90.0}, {'split': 'development', 'id': 'C100R1', 'file': 'Data/development/C100R1.csv', 'reference': 'Data/development/C050R1.csv', 'start_scan': 1, 'state': 'R1', 'true_ppm': 100.0}, {'split': 'development', 'id': 'C005R2', 'file': 'Data/development/C005R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 5.0}, {'split': 'development', 'id': 'C010R2', 'file': 'Data/development/C010R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 10.0}, {'split': 'development', 'id': 'C015R2', 'file': 'Data/development/C015R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 15.0}, {'split': 'development', 'id': 'C025R2', 'file': 'Data/development/C025R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 25.0}, {'split': 'development', 'id': 'C030R2', 'file': 'Data/development/C030R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 30.0}, {'split': 'development', 'id': 'C035R2', 'file': 'Data/development/C035R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 35.0}, {'split': 'development', 'id': 'C040R2', 'file': 'Data/development/C040R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 40.0}, {'split': 'development', 'id': 'C060R2', 'file': 'Data/development/C060R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 60.0}, {'split': 'development', 'id': 'C065R2', 'file': 'Data/development/C065R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 65.0}, {'split': 'development', 'id': 'C070R2', 'file': 'Data/development/C070R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 70.0}, {'split': 'development', 'id': 'C075R2', 'file': 'Data/development/C075R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 75.0}, {'split': 'development', 'id': 'C080R2', 'file': 'Data/development/C080R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 80.0}, {'split': 'development', 'id': 'C085R2', 'file': 'Data/development/C085R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 85.0}, {'split': 'development', 'id': 'C090R2', 'file': 'Data/development/C090R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 90.0}, {'split': 'development', 'id': 'C100R2', 'file': 'Data/development/C100R2.csv', 'reference': 'Data/development/C050R2.csv', 'start_scan': 1, 'state': 'R2', 'true_ppm': 100.0}, {'split': 'development', 'id': 'C005R3', 'file': 'Data/development/C005R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 5.0}, {'split': 'development', 'id': 'C010R3', 'file': 'Data/development/C010R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 10.0}, {'split': 'development', 'id': 'C015R3', 'file': 'Data/development/C015R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 15.0}, {'split': 'development', 'id': 'C020R3', 'file': 'Data/development/C020R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 20.0}, {'split': 'development', 'id': 'C025R3', 'file': 'Data/development/C025R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 25.0}, {'split': 'development', 'id': 'C030R3', 'file': 'Data/development/C030R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 30.0}, {'split': 'development', 'id': 'C035R3', 'file': 'Data/development/C035R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 35.0}, {'split': 'development', 'id': 'C040R3', 'file': 'Data/development/C040R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 40.0}, {'split': 'development', 'id': 'C045R3', 'file': 'Data/development/C045R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 45.0}, {'split': 'development', 'id': 'C055R3', 'file': 'Data/development/C055R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 55.0}, {'split': 'development', 'id': 'C060R3', 'file': 'Data/development/C060R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 60.0}, {'split': 'development', 'id': 'C065R3', 'file': 'Data/development/C065R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 65.0}, {'split': 'development', 'id': 'C070R3', 'file': 'Data/development/C070R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 70.0}, {'split': 'development', 'id': 'C075R3', 'file': 'Data/development/C075R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 75.0}, {'split': 'development', 'id': 'C080R3', 'file': 'Data/development/C080R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 80.0}, {'split': 'development', 'id': 'C085R3', 'file': 'Data/development/C085R3.csv', 'reference': 'Data/development/C050R3.csv', 'start_scan': 1, 'state': 'R3', 'true_ppm': 85.0}, {'split': 'validation', 'id': 'C012_1', 'file': 'Data/validation/R5_C012_1.csv', 'reference': 'Data/validation/R5_REF50_2.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 11.891620672353238}, {'split': 'validation', 'id': 'C012_2', 'file': 'Data/validation/R5_C012_2.csv', 'reference': 'Data/validation/R5_REF50_4.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 11.891620672353238}, {'split': 'validation', 'id': 'C012_3', 'file': 'Data/validation/R5_C012_3.csv', 'reference': 'Data/validation/R5_REF50_5.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 11.891620672353238}, {'split': 'validation', 'id': 'C028_1', 'file': 'Data/validation/R5_C028_1.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 27.880299251870323}, {'split': 'validation', 'id': 'C028_2', 'file': 'Data/validation/R5_C028_2.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 27.894211576846303}, {'split': 'validation', 'id': 'C028_3', 'file': 'Data/validation/R5_C028_3.csv', 'reference': 'Data/validation/R5_REF50_4.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 27.894211576846303}, {'split': 'validation', 'id': 'C037_1', 'file': 'Data/validation/R5_C037_1.csv', 'reference': 'Data/validation/R5_REF50_2.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 37.11133400200602}, {'split': 'validation', 'id': 'C037_2', 'file': 'Data/validation/R5_C037_2.csv', 'reference': 'Data/validation/R5_REF50_3.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 37.12995484194681}, {'split': 'validation', 'id': 'C037_3', 'file': 'Data/validation/R5_C037_3.csv', 'reference': 'Data/validation/R5_REF50_5.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 37.14859437751005}, {'split': 'validation', 'id': 'C053_1', 'file': 'Data/validation/R5_C053_1.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 52.95295295295295}, {'split': 'validation', 'id': 'C053_2', 'file': 'Data/validation/R5_C053_2.csv', 'reference': 'Data/validation/R5_REF50_3.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 52.95295295295295}, {'split': 'validation', 'id': 'C053_3', 'file': 'Data/validation/R5_C053_3.csv', 'reference': 'Data/validation/R5_REF50_4.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 52.92646323161581}, {'split': 'validation', 'id': 'C066_1', 'file': 'Data/validation/R5_C066_1.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 66.11528822055138}, {'split': 'validation', 'id': 'C066_2', 'file': 'Data/validation/R5_C066_2.csv', 'reference': 'Data/validation/R5_REF50_4.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 66.13146011038636}, {'split': 'validation', 'id': 'C066_3', 'file': 'Data/validation/R5_C066_3.csv', 'reference': 'Data/validation/R5_REF50_5.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 66.06516290726817}, {'split': 'validation', 'id': 'C082_1', 'file': 'Data/validation/R5_C082_1.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 82.36180904522612}, {'split': 'validation', 'id': 'C082_2', 'file': 'Data/validation/R5_C082_2.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 82.40321769733534}, {'split': 'validation', 'id': 'C082_3', 'file': 'Data/validation/R5_C082_3.csv', 'reference': 'Data/validation/R5_REF50_3.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 82.40321769733534}, {'split': 'validation', 'id': 'C088_1', 'file': 'Data/validation/R5_C088_1.csv', 'reference': 'Data/validation/R5_REF50_1.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 88.38612368024133}, {'split': 'validation', 'id': 'C088_2', 'file': 'Data/validation/R5_C088_2.csv', 'reference': 'Data/validation/R5_REF50_3.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 88.43058350100603}, {'split': 'validation', 'id': 'C088_3', 'file': 'Data/validation/R5_C088_3.csv', 'reference': 'Data/validation/R5_REF50_3.csv', 'start_scan': 97, 'state': 'R5', 'true_ppm': 88.47508807247105}]
RESIDUAL_SCALE = 0.0224078329711116

def _sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def _read_scans(path, start_scan):
    # Original frozen raw CSV reader and scan window: R1-R3=1-24, R5=97-120.
    values = np.genfromtxt(str(path), delimiter=',', skip_header=2, usecols=1)
    if values.ndim != 1 or values.size % 500 or not np.isfinite(values).all():
        raise ValueError('Expected finite two-column raw CSV samples in ' + str(path))
    scans = values.reshape(-1, 500)
    start = int(start_scan)-1
    if start < 0 or start+24 > len(scans): raise ValueError('Required 24 scans unavailable: '+str(path))
    return np.asarray([_preprocess(s) for s in scans[start:start+24]], dtype=np.float64)

def _preprocess(w):
    # Frozen: spike anchor -> cyclic shift -> [50:400] crop -> endpoint line removal -> 200 resample.
    anchor = int(np.argmax(np.abs(np.diff(w)))+1)
    crop = np.roll(w, -anchor)[50:400]
    axis = np.linspace(-1, 1, 350); endpoints = np.r_[np.arange(30), np.arange(320,350)]
    baseline = np.polyfit(axis[endpoints], crop[endpoints], 1)
    return np.interp(np.linspace(0,349,200), np.arange(350), crop-np.polyval(baseline,axis))

def _ls(raw, ref_raw):
    # Frozen B2: x=a*r50+b0+b1*t, C_LS=50*a.
    template = np.median(ref_raw, axis=0)
    position = np.linspace(-1,1,200)
    design = np.c_[template, np.ones(200), position]
    beta = np.linalg.lstsq(design, raw.T, rcond=None)[0].T
    fit = beta[:,0,None]*template[None,:]+beta[:,1,None]+beta[:,2,None]*position[None,:]
    return 50.0*beta[:,0], fit

def _load_models():
    loaded=[]
    for item in MODELS:
        path=ROOT/item['file']
        if not path.is_file() or _sha(path) != item['sha256']: raise RuntimeError('altered model: '+str(path))
        checkpoint=torch.load(path,map_location='cpu',weights_only=True)
        model=MSTCMFNet(item['seed']).eval()
        loaded_result=model.load_v01_checkpoint(checkpoint)
        if loaded_result.missing_keys or loaded_result.unexpected_keys: raise RuntimeError('strict load failure: '+path.name)
        loaded.append(model)
    return loaded

def _metrics(y,p):
    y=np.asarray(y,float);p=np.asarray(p,float);e=p-y;a=np.abs(e)
    return {'n':int(len(y)),'MAE':float(a.mean()),'RMSE':float(np.sqrt(np.mean(e*e))),'Bias':float(e.mean()),'R2':float(1-np.sum(e*e)/np.sum((y-y.mean())**2)),'MAPE':float(np.mean(a[y!=0]/np.abs(y[y!=0]))*100),'Median_AE':float(np.median(a)),'P90_AE':float(np.quantile(a,.9)),'Max_AE':float(a.max())}

def replay(split):
    rows=[r for r in RECORDS if r['split']==split]
    if not rows: raise ValueError('Unknown split: '+split)
    models=_load_models(); output=[]
    with torch.inference_mode():
        for r in rows:
            raw=_read_scans(ROOT/r['file'],r['start_scan']); ref=_read_scans(ROOT/r['reference'],r['start_scan'])
            cl,fit=_ls(raw,ref); x=torch.tensor(((raw-fit)/RESIDUAL_SCALE).astype(np.float32)[:,None,:])
            per_seed=[]
            for m in models:
                scan_prediction=cl+m(x).numpy()
                # torch.median with 24 elements selects the lower central value (index 11).
                per_seed.append(float(np.partition(scan_prediction,11)[11]))
            prediction=float(np.mean(per_seed)); err=prediction-r['true_ppm']
            output.append(dict(primary_id=r['id'],state=r['state'],true_ppm=r['true_ppm'],prediction_ppm=prediction,error_ppm=err,seed_predictions_ppm=';'.join(repr(v) for v in per_seed)))
    return output, _metrics([r['true_ppm'] for r in output],[r['prediction_ppm'] for r in output])

def main():
    split=sys.argv[1] if len(sys.argv)==2 else 'validation'
    rows, summary=replay(split)
    target=ROOT/('predictions_'+split+'.csv')
    with target.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(summary)
if __name__=='__main__': main()

"""MS-TCMFNet: Multi-Scale Tensor-Compressed MLP Fusion Network.

Faithful stand-alone implementation of frozen MR-TCCA H2/V3-V01/X00.

Input : standardized LS-fitting residual, shape (batch, 1, 200).
Output: scan-level concentration correction in ppm, shape (batch,).

The physical estimate C_LS, residual normalization, 24-scan median, and
five-seed ensembling belong to the original measurement protocol and are
not performed by this neural module.

The unused legacy Cross-Attention parameters are not stored or evaluated.
`seed` reproduces the V3-V01 initialization, including the legacy RNG
consumption before the prediction head and the dedicated MLP sub-seed.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Mapping

import torch
from torch import Tensor, nn


def _position_encoding(length: int = 10, width: int = 12) -> Tensor:
    positions = torch.arange(length, dtype=torch.float32).unsqueeze(1)
    even_dims = torch.arange(0, width, 2, dtype=torch.float32)
    angles = positions / (10000 ** (even_dims / width))
    encoding = torch.zeros(length, width)
    encoding[:, 0::2] = torch.sin(angles)
    encoding[:, 1::2] = torch.cos(angles)
    return encoding.unsqueeze(0)


def _mlp_subseed(seed: int) -> int:
    key = f"MR_TCCA_H2_V3_MLP_INIT_V1|{int(seed)}|D".encode("utf-8")
    return int.from_bytes(hashlib.sha256(key).digest()[:8], "little") % (2**63 - 1)


class DepthwiseSeparableConv1d(nn.Module):
    """H2 depthwise 24-channel conv, pointwise conv, and two GELUs."""

    def __init__(self, dilation: int, kernel_size: int = 3) -> None:
        super().__init__()
        self.dw = nn.Conv1d(
            24, 24, kernel_size=kernel_size,
            padding=dilation * (kernel_size // 2),
            dilation=dilation, groups=24,
        )
        self.pw = nn.Conv1d(24, 24, kernel_size=1)
        self.act = nn.GELU()

    def forward(self, x: Tensor) -> Tensor:
        return self.act(self.pw(self.act(self.dw(x))))


class MSTCMFNet(nn.Module):
    """The effective computation graph of frozen V01/X00, without ablations.

    For exact historical training initialization, use the matching V3 seed,
    e.g. 20261018 through 20261022. For trained legacy V01 weights, call
    `load_v01_checkpoint` to discard unused attention tensors safely.
    """

    def __init__(self, seed: int = 20261018) -> None:
        super().__init__()

        # Reproduce the original model's common-parameter RNG sequence.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(int(seed))
            self.stem = nn.Sequential(
                nn.Conv1d(1, 24, kernel_size=5, padding=2), nn.GELU()
            )
            self.local = nn.Sequential(
                DepthwiseSeparableConv1d(dilation=1),
                DepthwiseSeparableConv1d(dilation=2),
            )
            self.global_ = DepthwiseSeparableConv1d(dilation=4)
            self.pool = nn.AdaptiveAvgPool1d(20)

            self.token = nn.Linear(20, 10, bias=False)
            self.channel = nn.Linear(24, 12, bias=False)
            self.pos10 = nn.Parameter(_position_encoding(), requires_grad=False)

            # Original H2 built attention before LN/head, consuming RNG.
            # Keep that initialization sequence without registering any
            # inactive attention module in the final network.
            _unused_attention_for_rng = nn.MultiheadAttention(
                12, 2, batch_first=True
            )
            del _unused_attention_for_rng

            self.ln = nn.LayerNorm(12)
            self.head = nn.Sequential(
                nn.Linear(12, 12), nn.GELU(), nn.Linear(12, 1)
            )
            nn.init.zeros_(self.head[-1].weight)
            nn.init.zeros_(self.head[-1].bias)

        # The frozen V3 V01 protocol initialized its distinct MLP using
        # an independent SHA256-derived child seed.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(_mlp_subseed(seed))
            self.fusion = nn.Sequential(
                nn.Linear(24, 16), nn.GELU(), nn.Linear(16, 12)
            )

    def _compress(self, x: Tensor) -> Tensor:
        """[B,20,24] -> [B,10,12] with shared trainable projections."""
        x = self.token(x.transpose(1, 2)).transpose(1, 2)
        return self.channel(x)

    def forward(self, residual: Tensor) -> Tensor:
        h = self.stem(residual)
        local = self._compress(self.pool(self.local(h)).transpose(1, 2))
        global_features = self._compress(
            self.pool(self.global_(h)).transpose(1, 2)
        )
        q = local + self.pos10
        k = global_features + self.pos10
        fused = self.fusion(torch.cat((q, k), dim=-1))
        z = self.ln(q + fused)
        return self.head(z.mean(dim=1)).squeeze(1)

    def load_v01_checkpoint(
        self,
        checkpoint: str | Path | Mapping,
        *,
        map_location: str | torch.device = "cpu",
    ):
        """Strictly load V3-V01/X00 weights, removing only unused `attn.*`.

        Supports a legacy job checkpoint containing `state_dict` or a plain
        state_dict. All effective parameters must match exactly.
        """
        if isinstance(checkpoint, (str, Path)):
            checkpoint = torch.load(
                checkpoint, map_location=map_location, weights_only=True
            )
        state = checkpoint.get("state_dict", checkpoint)
        filtered = {k: v for k, v in state.items() if not k.startswith("attn.")}
        return self.load_state_dict(filtered, strict=True)
